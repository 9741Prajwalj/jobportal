<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="no" lang="no">;
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="robots" content="index,follow" />
        <meta name="description" content="" />
        <meta name="keywords" content="" />

        <title>Title</title>

    </head>

    <body>

        <p>Total messages: <?= $totalmsg ?></p>
        <p>Total messages: <?= $totalmsg ?></p>
        
        <p>Quota: <?= $quota ?></p>

    </body>
</html>